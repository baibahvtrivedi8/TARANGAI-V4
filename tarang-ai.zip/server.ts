import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import { INITIAL_STATIONS, generateForecast } from './src/data/mockStations.js';
import { Station, WaterQualityStatus } from './src/types.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Initialize Gemini AI lazily if key is configured
  const getAi = () => {
    const key = process.env.GEMINI_API_KEY;
    if (!key || key === 'MY_GEMINI_API_KEY') return null;
    return new GoogleGenAI({ apiKey: key });
  };

  // Helper calculation for global vitality score
  const computeVitalityIndex = (stations: Station[]): number => {
    if (!stations.length) return 80;
    const weights: Record<WaterQualityStatus, number> = {
      excellent: 100,
      good: 85,
      moderate: 65,
      poor: 40,
      severe: 15,
    };
    const sum = stations.reduce((acc, s) => acc + (weights[s.status] || 70), 0);
    return Number((sum / stations.length).toFixed(1));
  };

  // 1. GET /api/stations
  app.get('/api/stations', (req, res) => {
    res.json(INITIAL_STATIONS);
  });

  // 2. GET /api/stations/:id
  app.get('/api/stations/:id', (req, res) => {
    const station = INITIAL_STATIONS.find(s => s.station_id === req.params.id);
    if (!station) {
      res.status(404).json({ error: `Station with ID ${req.params.id} not found` });
      return;
    }
    res.json(station);
  });

  // 3. GET /api/stations/:id/forecast
  app.get('/api/stations/:id/forecast', (req, res) => {
    const parameter = (req.query.parameter as string) || 'dissolved_oxygen_mg_l';
    const forecast = generateForecast(req.params.id, parameter);
    res.json(forecast);
  });

  // 4. POST /api/search
  app.post('/api/search', async (req, res) => {
    const { query } = req.body || {};
    const textQuery = (query || '').toLowerCase().trim();

    let parsedFilter: any = {};
    let filteredStations = [...INITIAL_STATIONS];
    let aiSummary = '';

    // Filter matching logic
    if (textQuery.includes('severe')) {
      parsedFilter.status = 'severe';
      filteredStations = filteredStations.filter(s => s.status === 'severe');
    } else if (textQuery.includes('poor')) {
      parsedFilter.status = 'poor';
      filteredStations = filteredStations.filter(s => s.status === 'poor' || s.status === 'severe');
    } else if (textQuery.includes('excellent') || textQuery.includes('good') || textQuery.includes('clean')) {
      parsedFilter.status = 'good';
      filteredStations = filteredStations.filter(s => s.status === 'excellent' || s.status === 'good');
    } else if (textQuery.includes('river')) {
      parsedFilter.water_body_type = 'river';
      filteredStations = filteredStations.filter(s => s.water_body_type === 'river');
    } else if (textQuery.includes('lake')) {
      parsedFilter.water_body_type = 'lake';
      filteredStations = filteredStations.filter(s => s.water_body_type === 'lake');
    } else if (textQuery.includes('estuary') || textQuery.includes('bay')) {
      parsedFilter.water_body_type = 'estuary';
      filteredStations = filteredStations.filter(s => s.water_body_type === 'estuary');
    } else if (textQuery.includes('usgs')) {
      parsedFilter.source = 'usgs';
      filteredStations = filteredStations.filter(s => s.source === 'usgs');
    } else if (textQuery.includes('eea')) {
      parsedFilter.source = 'eea';
      filteredStations = filteredStations.filter(s => s.source === 'eea');
    } else if (textQuery.includes('gemstat')) {
      parsedFilter.source = 'gemstat';
      filteredStations = filteredStations.filter(s => s.source === 'gemstat');
    } else if (textQuery.includes('dissolved oxygen') || textQuery.includes('oxygen')) {
      parsedFilter.parameter = 'dissolved_oxygen_mg_l';
      filteredStations.sort((a, b) => {
        const valA = a.latest_readings.find(r => r.parameter === 'dissolved_oxygen_mg_l')?.value || 0;
        const valB = b.latest_readings.find(r => r.parameter === 'dissolved_oxygen_mg_l')?.value || 0;
        return valA - valB; // lowest oxygen first
      });
    } else if (textQuery.includes('turbidity') || textQuery.includes('sediment')) {
      parsedFilter.parameter = 'turbidity_ntu';
      filteredStations.sort((a, b) => {
        const valA = a.latest_readings.find(r => r.parameter === 'turbidity_ntu')?.value || 0;
        const valB = b.latest_readings.find(r => r.parameter === 'turbidity_ntu')?.value || 0;
        return valB - valA; // highest turbidity first
      });
    }

    // Attempt Gemini AI summary if configured
    try {
      const ai = getAi();
      if (ai) {
        const response = await ai.models.generateContent({
          model: 'gemini-2.5-flash',
          contents: `You are TARANG AI, an environmental water monitoring agent. Provide a 2-3 sentence executive scientific analysis answering the user prompt: "${query}". Refer to these matched stations: ${JSON.stringify(filteredStations.map(s => ({ name: s.name, status: s.status, readings: s.latest_readings })))}. Emphasize key parameters like Dissolved Oxygen, Turbidity, pH, and Nitrate levels. Keep tone concise, authoritative, and environmental.`,
        });
        aiSummary = response.text || '';
      }
    } catch (err) {
      console.warn('Gemini query processing skipped/fallback:', err);
    }

    if (!aiSummary) {
      const total = filteredStations.length;
      const severeCount = filteredStations.filter(s => s.status === 'severe' || s.status === 'poor').length;
      aiSummary = `Query matched ${total} water quality monitoring node${total === 1 ? '' : 's'}. ${severeCount > 0 ? `Detected ${severeCount} station(s) with elevated pollution risk or hypoxia trends.` : 'All matched telemetry nodes indicate stable environmental parameters.'}`;
    }

    res.json({
      query: query || '',
      parsed_filter: parsedFilter,
      results: filteredStations,
      ai_summary: aiSummary,
    });
  });

  // Direct alias routes if frontend calls without /api prefix
  app.get('/stations', (req, res) => res.redirect('/api/stations'));
  app.get('/stations/:id', (req, res) => res.redirect(`/api/stations/${req.params.id}`));

  // Vite development middleware vs production static bundle
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`TARANG AI HydroWatch Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
