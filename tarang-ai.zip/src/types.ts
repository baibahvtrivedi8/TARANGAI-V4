export type WaterQualityStatus = 'excellent' | 'good' | 'moderate' | 'poor' | 'severe';

export interface Reading {
  parameter: string;
  value: number;
  unit: string;
  timestamp: string;
}

export interface Station {
  station_id: string;
  source: 'usgs' | 'epa_wqx' | 'eea' | 'gemstat';
  name: string;
  country: string;
  latitude: number;
  longitude: number;
  water_body_type: string;
  latest_readings: Reading[];
  status: WaterQualityStatus;
  last_updated: string;
}

export interface ForecastHistoryItem {
  timestamp: string;
  value: number;
}

export interface Forecast {
  station_id: string;
  parameter: string;
  history: ForecastHistoryItem[];
  projected_crossing_date: string;
  current_status: WaterQualityStatus;
  projected_status_in_90_days: WaterQualityStatus;
  confidence: number;
  method: string;
}

export interface ParsedFilter {
  parameter?: string;
  max_value?: number;
  min_value?: number;
  status?: WaterQualityStatus;
  water_body_type?: string;
  country?: string;
}

export interface SearchResponse {
  query: string;
  parsed_filter: ParsedFilter;
  results: Station[];
  ai_summary?: string;
}

export interface StationAggregateStats {
  total_stations: number;
  vitality_index: number; // 0 - 100
  mean_temperature: number; // °C
  status_counts: Record<WaterQualityStatus, number>;
  sources: string[];
}
