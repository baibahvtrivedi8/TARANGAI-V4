import React, { useState } from 'react';

interface HeaderProps {
  currentRoute: string; // '/' | '/station' | '/assistant'
  onNavigate: (route: string) => void;
}

export const Header: React.FC<HeaderProps> = ({ currentRoute, onNavigate }) => {
  const [searchInput, setSearchInput] = useState('');

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchInput.trim()) {
      onNavigate(`/assistant?q=${encodeURIComponent(searchInput.trim())}`);
    }
  };

  return (
    <header class="flex justify-between items-center px-4 md:px-margin-desktop py-4 w-full z-50 bg-forest-deep/90 backdrop-blur-xl border-b border-forest-deep/30 top-0 sticky">
      <div class="flex items-center gap-3 cursor-pointer" onClick={() => onNavigate('/')}>
        <div class="h-10 w-10 rounded-xl bg-primary-container/80 flex items-center justify-center border border-primary/30 text-primary">
          <span class="material-symbols-outlined text-2xl">eco</span>
        </div>
        <span class="font-headline-lg text-xl md:text-2xl font-extrabold text-sage-muted tracking-tighter uppercase editorial-wide">
          TARANG AI
        </span>
      </div>

      <nav class="hidden md:flex items-center gap-8">
        <button
          onClick={() => onNavigate('/')}
          class={`font-body-md text-body-md transition-all cursor-pointer ${
            currentRoute === '/'
              ? 'text-primary font-bold border-b-2 border-primary pb-1'
              : 'text-on-surface-variant font-medium hover:text-primary'
          }`}
        >
          Dashboard
        </button>

        <button
          onClick={() => onNavigate('/station/gemstat-amazon-03')}
          class={`font-body-md text-body-md transition-all cursor-pointer ${
            currentRoute.startsWith('/station')
              ? 'text-primary font-bold border-b-2 border-primary pb-1'
              : 'text-on-surface-variant font-medium hover:text-primary'
          }`}
        >
          Stations
        </button>

        <button
          onClick={() => onNavigate('/assistant')}
          class={`font-body-md text-body-md transition-all cursor-pointer flex items-center gap-1 ${
            currentRoute === '/assistant'
              ? 'text-primary font-bold border-b-2 border-primary pb-1'
              : 'text-on-surface-variant font-medium hover:text-primary'
          }`}
        >
          <span class="material-symbols-outlined text-sm">psychology</span>
          AI Assistant
        </button>
      </nav>

      <div class="flex items-center gap-4 md:gap-6">
        <form onSubmit={handleSearchSubmit} class="relative hidden lg:block">
          <span class="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-outline text-sm">
            search
          </span>
          <input
            type="text"
            value={searchInput}
            onChange={e => setSearchInput(e.target.value)}
            placeholder="Search stations or parameters..."
            class="bg-surface-container-highest border-none rounded-full pl-9 pr-4 py-1.5 text-body-sm font-body-sm focus:ring-1 focus:ring-primary w-60 text-white placeholder:text-outline transition-all"
          />
        </form>

        <button
          onClick={() => onNavigate('/assistant')}
          class="material-symbols-outlined text-on-surface-variant hover:text-primary cursor-pointer p-1 rounded-full transition-colors"
          title="AI Assistant"
        >
          psychology
        </button>

        <span class="material-symbols-outlined text-on-surface-variant hover:text-primary cursor-pointer p-1 rounded-full transition-colors">
          notifications
        </span>

        <span class="material-symbols-outlined text-on-surface-variant hover:text-primary cursor-pointer p-1 rounded-full transition-colors">
          settings
        </span>

        <div class="h-8 w-8 rounded-full bg-primary-container flex items-center justify-center overflow-hidden border border-primary/30">
          <span class="material-symbols-outlined text-primary text-sm">water_drop</span>
        </div>
      </div>
    </header>
  );
};
