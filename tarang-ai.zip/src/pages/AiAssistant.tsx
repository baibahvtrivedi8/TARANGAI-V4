import React, { useEffect, useState } from 'react';
import { Station, SearchResponse } from '../types';
import { searchStations } from '../services/api';

interface ChatMessage {
  id: string;
  sender: 'user' | 'assistant';
  queryText?: string;
  summaryText?: string;
  matchedStations?: Station[];
  parsedFilter?: any;
  timestamp: string;
}

interface AiAssistantProps {
  initialQuery?: string;
  onNavigate: (route: string) => void;
}

const DEFAULT_RECENT_QUERIES = [
  'Analyze severe water hypoxia stations globally',
  'Show Rhine & European river monitoring nodes',
  'Find stations with high turbidity and nitrate levels',
  'Check Amazon Basin Dissolved Oxygen telemetry',
  'List all EPA and USGS water quality stations',
];

export const AiAssistant: React.FC<AiAssistantProps> = ({ initialQuery = '', onNavigate }) => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputText, setInputText] = useState('');
  const [loading, setLoading] = useState(false);
  const [recentQueries, setRecentQueries] = useState<string[]>(DEFAULT_RECENT_QUERIES);

  // Initial welcome message
  useEffect(() => {
    setMessages([
      {
        id: 'msg-welcome',
        sender: 'assistant',
        summaryText:
          'Welcome to TARANG AI Environmental Assistant. I am connected directly to real-time global water quality monitoring networks (USGS, EPA WQX, EEA, GEMStat). Ask me to analyze water bodies, identify pollution risk, filter telemetry by parameter, or assess 90-day forecast trends.',
        matchedStations: [],
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      },
    ]);

    if (initialQuery) {
      handleSendQuery(initialQuery);
    }
  }, [initialQuery]);

  const handleSendQuery = async (queryText: string) => {
    if (!queryText.trim() || loading) return;

    const userMsgId = `user-${Date.now()}`;
    const userMsg: ChatMessage = {
      id: userMsgId,
      sender: 'user',
      queryText,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages(prev => [...prev, userMsg]);
    setInputText('');
    setLoading(true);

    // Save query to recent analyses sidebar
    if (!recentQueries.includes(queryText)) {
      setRecentQueries(prev => [queryText, ...prev.slice(0, 9)]);
    }

    try {
      const response: SearchResponse = await searchStations(queryText);

      const aiMsg: ChatMessage = {
        id: `ai-${Date.now()}`,
        sender: 'assistant',
        summaryText: response.ai_summary || 'Analysis completed successfully.',
        matchedStations: response.results || [],
        parsedFilter: response.parsed_filter,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      setMessages(prev => [...prev, aiMsg]);
    } catch (err) {
      console.error('Search API query failed', err);
      setMessages(prev => [
        ...prev,
        {
          id: `ai-err-${Date.now()}`,
          sender: 'assistant',
          summaryText:
            'Unable to process query over network layer. Displaying cached active stations matching parameters.',
          matchedStations: [],
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div class="h-[calc(100vh-72px)] w-full flex overflow-hidden bg-background">
      {/* Left Sidebar: Recent Analyses */}
      <aside class="hidden lg:flex flex-col h-full w-80 bg-surface-dim border-r border-forest-deep/20 py-6 px-4 gap-4 z-40">
        <div>
          <div class="flex items-center gap-2 mb-1">
            <span class="material-symbols-outlined text-primary text-xl">history</span>
            <h2 class="font-headline-lg-mobile text-lg font-bold text-sage-muted editorial-wide">
              Recent Analyses
            </h2>
          </div>
          <p class="font-body-sm text-xs text-outline-variant">
            Saved environmental AI prompts & queries
          </p>
        </div>

        <div class="flex flex-col gap-2 overflow-y-auto flex-grow pr-1">
          {recentQueries.map((query, idx) => (
            <div
              key={idx}
              onClick={() => handleSendQuery(query)}
              class="glass-panel rounded-xl p-3 text-xs text-on-surface-variant hover:text-white hover:border-primary/40 border border-primary/10 cursor-pointer transition-all active:scale-98 flex items-start gap-2 group"
            >
              <span class="material-symbols-outlined text-sm text-primary group-hover:scale-110 transition-transform">
                travel_explore
              </span>
              <span class="font-body-sm line-clamp-2">{query}</span>
            </div>
          ))}
        </div>

        <button
          onClick={() => handleSendQuery('Give me a global executive summary of all station water statuses')}
          class="w-full bg-surface-container-high text-primary border border-primary/20 py-3 px-4 rounded-xl font-bold flex items-center justify-center gap-2 hover:bg-primary/20 transition-all text-xs uppercase tracking-wider cursor-pointer"
        >
          <span class="material-symbols-outlined text-sm">analytics</span>
          Global Executive Summary
        </button>
      </aside>

      {/* Main Chat Conversation Area */}
      <main class="flex-grow flex flex-col h-full overflow-hidden bg-forest-deep/50 relative">
        {/* Messages Stream */}
        <div class="flex-grow overflow-y-auto p-4 md:p-8 space-y-6">
          {messages.map(msg => {
            if (msg.sender === 'user') {
              return (
                <div key={msg.id} class="flex justify-end">
                  <div class="bg-primary text-forest-deep rounded-2xl rounded-tr-none px-6 py-4 max-w-xl shadow-lg">
                    <p class="font-body-md text-sm md:text-base font-bold">{msg.queryText}</p>
                    <span class="font-label-caps text-[10px] text-forest-deep/70 block text-right mt-1">
                      {msg.timestamp}
                    </span>
                  </div>
                </div>
              );
            }

            return (
              <div key={msg.id} class="flex items-start gap-3 max-w-4xl">
                <div class="h-10 w-10 rounded-2xl bg-primary-container flex items-center justify-center text-primary border border-primary/30 flex-shrink-0 mt-1">
                  <span class="material-symbols-outlined text-xl">psychology</span>
                </div>

                <div class="flex-grow space-y-4">
                  {/* AI Executive Summary Card */}
                  <div class="glass-panel organic-card rounded-3xl p-6 border border-primary/10 shadow-xl">
                    <div class="flex justify-between items-center mb-3">
                      <span class="font-label-caps text-[11px] text-primary uppercase font-black tracking-widest flex items-center gap-1.5">
                        <span class="h-2 w-2 rounded-full bg-secondary active-glow" />
                        TARANG AI SYNTHESIS
                      </span>
                      <span class="font-label-caps text-[10px] text-outline-variant">
                        {msg.timestamp}
                      </span>
                    </div>

                    <p class="font-body-md text-sm md:text-base text-on-surface leading-relaxed font-medium">
                      {msg.summaryText}
                    </p>
                  </div>

                  {/* Embedded Result Cards (Matching Stations) */}
                  {msg.matchedStations && msg.matchedStations.length > 0 && (
                    <div class="space-y-3">
                      <div class="flex justify-between items-center px-1">
                        <span class="font-label-caps text-xs text-outline-variant uppercase font-bold">
                          Matched Monitoring Nodes ({msg.matchedStations.length})
                        </span>
                      </div>

                      <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {msg.matchedStations.map(station => (
                          <div
                            key={station.station_id}
                            onClick={() => onNavigate(`/station/${station.station_id}`)}
                            class="glass-panel organic-card rounded-2xl p-5 border border-primary/10 hover:border-primary/40 shadow-lg cursor-pointer transition-all active:scale-98 flex flex-col justify-between group"
                          >
                            <div>
                              <div class="flex justify-between items-start mb-2">
                                <span class="font-label-caps text-[10px] text-primary uppercase font-bold">
                                  {station.source.toUpperCase()} • {station.water_body_type}
                                </span>
                                <span class="px-2 py-0.5 rounded-full text-[10px] font-black uppercase text-black bg-secondary">
                                  {station.status}
                                </span>
                              </div>

                              <h4 class="font-headline-lg-mobile text-base text-white font-bold group-hover:text-primary transition-colors mb-2">
                                {station.name}
                              </h4>

                              <div class="grid grid-cols-2 gap-2 text-xs font-label-caps border-t border-primary/10 pt-3 mt-2">
                                <div>
                                  <span class="text-outline-variant block">Dissolved Oxygen:</span>
                                  <span class="text-white font-bold">
                                    {station.latest_readings.find(r => r.parameter === 'dissolved_oxygen_mg_l')?.value || '--'} mg/L
                                  </span>
                                </div>
                                <div>
                                  <span class="text-outline-variant block">Turbidity:</span>
                                  <span class="text-white font-bold">
                                    {station.latest_readings.find(r => r.parameter === 'turbidity_ntu')?.value || '--'} NTU
                                  </span>
                                </div>
                              </div>
                            </div>

                            <div class="mt-3 text-right">
                              <span class="font-label-caps text-[11px] text-primary font-bold flex items-center justify-end gap-1 group-hover:underline">
                                Inspect Node Telemetry
                                <span class="material-symbols-outlined text-sm">arrow_forward</span>
                              </span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            );
          })}

          {loading && (
            <div class="flex items-center gap-3 max-w-md">
              <div class="h-10 w-10 rounded-2xl bg-primary-container flex items-center justify-center text-primary border border-primary/30 animate-pulse">
                <span class="material-symbols-outlined text-xl">psychology</span>
              </div>
              <div class="glass-panel rounded-2xl p-4 text-xs font-label-caps text-primary animate-pulse border border-primary/20">
                Running neural search and regression forecasting across global station nodes...
              </div>
            </div>
          )}
        </div>

        {/* Bottom Input Field Box */}
        <div class="p-4 md:p-6 bg-forest-deep/90 border-t border-forest-deep/30">
          <form
            onSubmit={e => {
              e.preventDefault();
              handleSendQuery(inputText);
            }}
            class="max-w-4xl mx-auto relative flex items-center"
          >
            <input
              type="text"
              value={inputText}
              onChange={e => setInputText(e.target.value)}
              placeholder="Ask TARANG AI (e.g. 'Analyze stations with low dissolved oxygen' or 'Show Ganges river status')..."
              class="w-full bg-surface-container-highest/90 border border-primary/20 rounded-2xl py-4 pl-5 pr-14 text-sm text-white placeholder:text-outline focus:outline-none focus:ring-1 focus:ring-primary shadow-xl font-body-md"
            />
            <button
              type="submit"
              disabled={loading || !inputText.trim()}
              class="absolute right-2 bg-primary text-forest-deep p-2.5 rounded-xl disabled:opacity-40 hover:bg-leaf-glow transition-all active:scale-95 cursor-pointer flex items-center justify-center"
            >
              <span class="material-symbols-outlined text-xl font-bold">send</span>
            </button>
          </form>
        </div>
      </main>
    </div>
  );
};
