import React, { useEffect, useState } from 'react';
import { Station, Forecast, WaterQualityStatus, Reading } from '../types';
import { fetchStationById, fetchStationForecast } from '../services/api';

interface StationDetailProps {
  stationId: string;
  onNavigate: (route: string) => void;
}

const STATUS_COLORS: Record<WaterQualityStatus, string> = {
  excellent: '#adcebd', // Sage/Primary
  good: '#b2d094',      // Secondary
  moderate: '#efbc98',  // Tertiary
  poor: '#8C5E45',      // Terracotta
  severe: '#ffb4ab',    // Error
};

export const StationDetail: React.FC<StationDetailProps> = ({ stationId, onNavigate }) => {
  const [station, setStation] = useState<Station | null>(null);
  const [forecast, setForecast] = useState<Forecast | null>(null);
  const [selectedParam, setSelectedParam] = useState<string>('dissolved_oxygen_mg_l');
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let isMounted = true;
    setLoading(true);
    setError(null);

    Promise.all([
      fetchStationById(stationId),
      fetchStationForecast(stationId, selectedParam, 90),
    ])
      .then(([stationData, forecastData]) => {
        if (isMounted) {
          setStation(stationData);
          setForecast(forecastData);
          setLoading(false);
        }
      })
      .catch(err => {
        if (isMounted) {
          console.error('Error fetching station detail:', err);
          setError(`Could not load station data for "${stationId}"`);
          setLoading(false);
        }
      });

    return () => {
      isMounted = false;
    };
  }, [stationId, selectedParam]);

  if (loading) {
    return (
      <div class="h-[calc(100vh-72px)] w-full flex flex-col justify-center items-center p-8 bg-background">
        <div class="h-12 w-12 border-4 border-primary/20 border-t-primary rounded-full animate-spin mb-4" />
        <p class="font-body-md text-sage-muted animate-pulse font-medium">
          Connecting to station telemetry node...
        </p>
      </div>
    );
  }

  if (error || !station) {
    return (
      <div class="h-[calc(100vh-72px)] w-full flex flex-col justify-center items-center p-8 bg-background text-center">
        <div class="h-16 w-16 bg-error/20 rounded-full flex items-center justify-center text-error mb-4">
          <span class="material-symbols-outlined text-3xl">warning</span>
        </div>
        <h3 class="font-headline-lg text-2xl text-white font-bold mb-2">Station Offline</h3>
        <p class="font-body-md text-outline-variant max-w-md mb-6">{error || 'Station data not found'}</p>
        <button
          onClick={() => onNavigate('/')}
          class="bg-primary text-forest-deep px-6 py-3 rounded-full font-bold hover:bg-leaf-glow transition-all uppercase text-xs tracking-widest cursor-pointer"
        >
          Return to Global View
        </button>
      </div>
    );
  }

  // Get specific readings
  const getReading = (paramKey: string): Reading | undefined => {
    return station.latest_readings.find(r => r.parameter === paramKey);
  };

  const doReading = getReading('dissolved_oxygen_mg_l');
  const turbidityReading = getReading('turbidity_ntu');
  const nitrateReading = getReading('nitrate_mg_l');
  const bodReading = getReading('biochemical_oxygen_demand_mg_l');
  const phReading = getReading('ph');
  const tempReading = getReading('temperature_c');

  // SVG Chart path calculation
  const renderChartPath = () => {
    if (!forecast || !forecast.history.length) return { solidD: '', dashedD: '', points: [] };

    const width = 640;
    const height = 180;
    const padding = 20;

    const values = forecast.history.map(h => h.value);
    const minVal = Math.min(...values) * 0.8;
    const maxVal = Math.max(...values) * 1.2 || 1;

    const points = forecast.history.map((item, index) => {
      const x = padding + (index / (forecast.history.length - 1)) * (width - 2 * padding);
      const normalizedY = (item.value - minVal) / (maxVal - minVal || 1);
      const y = height - padding - normalizedY * (height - 2 * padding);
      return { x, y, value: item.value, timestamp: item.timestamp };
    });

    // Solid path up to last historical point (index length - 2)
    const solidPoints = points.slice(0, points.length - 1);
    const projectedPoints = points.slice(points.length - 2);

    const createD = (pts: { x: number; y: number }[]) => {
      if (pts.length < 2) return '';
      return pts.reduce((acc, p, i) => (i === 0 ? `M ${p.x},${p.y}` : `${acc} L ${p.x},${p.y}`), '');
    };

    return {
      solidD: createD(solidPoints),
      dashedD: createD(projectedPoints),
      points,
    };
  };

  const chartData = renderChartPath();

  return (
    <div class="min-h-[calc(100vh-72px)] w-full bg-background p-4 md:p-margin-desktop overflow-y-auto">
      {/* Top Navigation Bar */}
      <div class="flex flex-wrap items-center justify-between gap-4 mb-6">
        <button
          onClick={() => onNavigate('/')}
          class="flex items-center gap-2 text-on-surface-variant hover:text-primary transition-colors font-body-sm text-sm font-bold cursor-pointer active:scale-95"
        >
          <span class="material-symbols-outlined text-lg">arrow_back</span>
          Global View
        </button>

        <div class="flex items-center gap-3">
          <span class="font-label-caps text-xs text-outline-variant uppercase">SOURCE:</span>
          <span class="bg-surface-container-high text-primary px-3 py-1 rounded-full text-xs font-bold font-label-caps border border-primary/20">
            {station.source.toUpperCase()} NODE
          </span>
          <span class="text-outline-variant text-xs">•</span>
          <span class="font-label-caps text-xs text-outline-variant">
            UPDATED: {new Date(station.last_updated).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
          </span>
        </div>
      </div>

      {/* Station Title Header */}
      <div class="glass-panel organic-card rounded-[32px] p-6 md:p-8 mb-8 border border-primary/10 shadow-2xl">
        <div class="flex flex-wrap justify-between items-start gap-4 mb-4">
          <div>
            <div class="flex items-center gap-3 mb-2">
              <span
                class="px-3 py-1 rounded-full text-xs font-black uppercase tracking-wider text-black"
                style={{ backgroundColor: STATUS_COLORS[station.status] }}
              >
                {station.status} STATUS
              </span>
              <span class="font-label-caps text-xs text-outline-variant uppercase tracking-widest">
                ID: {station.station_id}
              </span>
            </div>

            <h1 class="font-headline-lg text-2xl md:text-4xl font-extrabold text-white mb-2 editorial-wide">
              {station.name}
            </h1>

            <p class="font-body-md text-outline-variant text-sm md:text-base">
              {station.country} • {station.water_body_type.toUpperCase()} CATCHMENT • Coordinates:{' '}
              <span class="font-label-caps text-primary">
                {station.latitude.toFixed(4)}°N, {station.longitude.toFixed(4)}°E
              </span>
            </p>
          </div>

          <div class="flex gap-3">
            <button
              onClick={() => onNavigate('/assistant')}
              class="bg-sage-muted text-forest-deep px-5 py-3 rounded-xl font-bold flex items-center gap-2 hover:bg-primary transition-all active:scale-95 text-xs uppercase tracking-wider cursor-pointer"
            >
              <span class="material-symbols-outlined text-base">psychology</span>
              Ask AI Assistant
            </button>
          </div>
        </div>
      </div>

      {/* Bento Grid: 4 Organic Cards (Field Mapping applied) */}
      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {/* Card 1: Dissolved Oxygen (mg/L) - Replaces Current Humidity */}
        <div class="glass-panel organic-card rounded-3xl p-6 border border-primary/10 shadow-xl flex flex-col justify-between">
          <div>
            <div class="flex justify-between items-start mb-4">
              <div class="bg-primary-container/30 px-3 py-1 rounded-full border border-primary/20">
                <span class="font-label-caps text-[10px] text-primary uppercase tracking-widest font-black">
                  Primary Vital
                </span>
              </div>
              <span class="material-symbols-outlined text-primary">air</span>
            </div>

            <h3 class="font-label-caps text-xs text-outline-variant uppercase tracking-widest mb-1 font-bold">
              Dissolved Oxygen
            </h3>

            <div class="flex items-baseline gap-2 mb-2">
              <span class="font-data-display text-4xl text-secondary font-extrabold">
                {doReading ? doReading.value : '7.8'}
              </span>
              <span class="font-body-sm text-sm text-outline-variant font-bold">mg/L</span>
            </div>

            <div class="h-2 w-full bg-surface-container-highest rounded-full overflow-hidden mb-3">
              <div
                class="h-full bg-secondary rounded-full"
                style={{ width: `${Math.min(100, ((doReading?.value || 7.8) / 12) * 100)}%` }}
              />
            </div>
          </div>

          <p class="font-body-sm text-xs text-outline-variant">
            Target aquatic health range:{' '}
            <span class="text-white font-bold">6.5 - 10.0 mg/L</span>
          </p>
        </div>

        {/* Card 2: Turbidity (NTU) - Replaces Soil Moisture */}
        <div class="glass-panel organic-card rounded-3xl p-6 border border-primary/10 shadow-xl flex flex-col justify-between">
          <div>
            <div class="flex justify-between items-start mb-4">
              <div class="bg-primary-container/30 px-3 py-1 rounded-full border border-primary/20">
                <span class="font-label-caps text-[10px] text-primary uppercase tracking-widest font-black">
                  Water Clarity
                </span>
              </div>
              <span class="material-symbols-outlined text-tertiary">water</span>
            </div>

            <h3 class="font-label-caps text-xs text-outline-variant uppercase tracking-widest mb-1 font-bold">
              Turbidity Index
            </h3>

            <div class="flex items-baseline gap-2 mb-2">
              <span class="font-data-display text-4xl text-tertiary font-extrabold">
                {turbidityReading ? turbidityReading.value : '14.2'}
              </span>
              <span class="font-body-sm text-sm text-outline-variant font-bold">NTU</span>
            </div>

            <div class="h-2 w-full bg-surface-container-highest rounded-full overflow-hidden mb-3">
              <div
                class="h-full bg-tertiary rounded-full"
                style={{ width: `${Math.min(100, ((turbidityReading?.value || 14.2) / 50) * 100)}%` }}
              />
            </div>
          </div>

          <p class="font-body-sm text-xs text-outline-variant">
            Acceptable drinking/river clarity:{' '}
            <span class="text-white font-bold">&lt; 15.0 NTU</span>
          </p>
        </div>

        {/* Card 3: Nitrate / BOD - Replaces Carbon Flux */}
        <div class="glass-panel organic-card rounded-3xl p-6 border border-primary/10 shadow-xl flex flex-col justify-between">
          <div>
            <div class="flex justify-between items-start mb-4">
              <div class="bg-primary-container/30 px-3 py-1 rounded-full border border-primary/20">
                <span class="font-label-caps text-[10px] text-primary uppercase tracking-widest font-black">
                  Nutrient Load
                </span>
              </div>
              <span class="material-symbols-outlined text-terracotta-warm">biotech</span>
            </div>

            <h3 class="font-label-caps text-xs text-outline-variant uppercase tracking-widest mb-1 font-bold">
              Nitrate Concentration
            </h3>

            <div class="flex items-baseline gap-2 mb-2">
              <span class="font-data-display text-4xl text-terracotta-warm font-extrabold">
                {nitrateReading ? nitrateReading.value : '2.4'}
              </span>
              <span class="font-body-sm text-sm text-outline-variant font-bold">mg/L</span>
            </div>

            <div class="text-xs text-outline-variant flex justify-between border-t border-primary/10 pt-2 mb-2 font-label-caps">
              <span>BOD Level:</span>
              <span class="text-white font-bold">{bodReading ? bodReading.value : '1.8'} mg/L</span>
            </div>
          </div>

          <p class="font-body-sm text-xs text-outline-variant">
            Nitrate standard threshold:{' '}
            <span class="text-white font-bold">&lt; 5.0 mg/L</span>
          </p>
        </div>

        {/* Card 4: Device Health / Sensor Metadata - Replaces Solar Array / Mesh Uplink */}
        <div class="glass-panel organic-card rounded-3xl p-6 border border-primary/10 shadow-xl flex flex-col justify-between">
          <div>
            <div class="flex justify-between items-start mb-4">
              <div class="bg-primary-container/30 px-3 py-1 rounded-full border border-primary/20">
                <span class="font-label-caps text-[10px] text-primary uppercase tracking-widest font-black">
                  Telemetry Node
                </span>
              </div>
              <span class="material-symbols-outlined text-secondary">sensors</span>
            </div>

            <h3 class="font-label-caps text-xs text-outline-variant uppercase tracking-widest mb-3 font-bold">
              Station Sensor Metadata
            </h3>

            <div class="space-y-2 text-xs font-label-caps">
              <div class="flex justify-between text-outline-variant">
                <span>Data Source:</span>
                <span class="text-primary font-bold">{station.source.toUpperCase()}</span>
              </div>
              <div class="flex justify-between text-outline-variant">
                <span>Body Type:</span>
                <span class="text-white font-bold capitalize">{station.water_body_type}</span>
              </div>
              <div class="flex justify-between text-outline-variant">
                <span>pH Reading:</span>
                <span class="text-white font-bold">{phReading ? phReading.value : '7.4'}</span>
              </div>
              <div class="flex justify-between text-outline-variant">
                <span>Water Temp:</span>
                <span class="text-white font-bold">{tempReading ? tempReading.value : '16.2'} °C</span>
              </div>
            </div>
          </div>

          <div class="mt-4 pt-2 border-t border-primary/10 flex justify-between items-center text-xs">
            <span class="text-outline-variant font-label-caps">Uptime Status:</span>
            <span class="text-secondary font-bold flex items-center gap-1">
              <span class="h-2 w-2 rounded-full bg-secondary active-glow" /> 99.8% Online
            </span>
          </div>
        </div>
      </div>

      {/* Middle Section: Temporal Trends Chart + Anomaly / Forecast Panel */}
      <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Temporal Trends SVG Chart (2 columns) */}
        <div class="lg:col-span-2 glass-panel organic-card rounded-[32px] p-6 md:p-8 border border-primary/10 shadow-2xl">
          <div class="flex flex-wrap justify-between items-center gap-4 mb-6">
            <div>
              <div class="flex items-center gap-2 mb-1">
                <span class="material-symbols-outlined text-primary text-xl">timeline</span>
                <h3 class="font-headline-lg text-xl text-white font-extrabold editorial-wide">
                  Temporal Trends & 90-Day Projection
                </h3>
              </div>
              <p class="font-body-sm text-xs text-outline-variant">
                Historical monitoring telemetry (solid) vs hydrological AI forecast model (dashed)
              </p>
            </div>

            {/* Parameter Selector */}
            <select
              value={selectedParam}
              onChange={e => setSelectedParam(e.target.value)}
              class="bg-surface-container-highest text-white text-xs font-label-caps rounded-xl px-4 py-2 border border-primary/20 focus:outline-none focus:ring-1 focus:ring-primary cursor-pointer"
            >
              <option value="dissolved_oxygen_mg_l">Dissolved Oxygen (mg/L)</option>
              <option value="turbidity_ntu">Turbidity (NTU)</option>
              <option value="nitrate_mg_l">Nitrate (mg/L)</option>
              <option value="biochemical_oxygen_demand_mg_l">BOD (mg/L)</option>
            </select>
          </div>

          {/* SVG Chart Rendering */}
          <div class="relative w-full h-56 bg-surface-container-lowest/60 rounded-2xl p-4 border border-primary/10 overflow-hidden flex items-center justify-center">
            {chartData.solidD ? (
              <svg viewBox="0 0 640 180" class="w-full h-full overflow-visible">
                {/* Horizontal Grid lines */}
                <line x1="20" y1="30" x2="620" y2="30" stroke="rgba(173, 206, 189, 0.08)" strokeWidth="1" />
                <line x1="20" y1="80" x2="620" y2="80" stroke="rgba(173, 206, 189, 0.08)" strokeWidth="1" />
                <line x1="20" y1="130" x2="620" y2="130" stroke="rgba(173, 206, 189, 0.08)" strokeWidth="1" />

                {/* Historical Path (Solid) */}
                <path
                  d={chartData.solidD}
                  fill="none"
                  stroke="#adcebd"
                  strokeWidth="3"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />

                {/* Forecast Path (Dashed) */}
                <path
                  d={chartData.dashedD}
                  fill="none"
                  stroke="#efbc98"
                  strokeWidth="3"
                  strokeDasharray="6 6"
                  strokeLinecap="round"
                />

                {/* Point markers */}
                {chartData.points.map((pt, idx) => {
                  const isProjected = idx >= chartData.points.length - 2;
                  return (
                    <g key={idx}>
                      <circle
                        cx={pt.x}
                        cy={pt.y}
                        r={isProjected ? 4 : 3}
                        fill={isProjected ? '#efbc98' : '#adcebd'}
                      />
                    </g>
                  );
                })}
              </svg>
            ) : (
              <p class="font-body-sm text-xs text-outline-variant">Rendering trend forecast...</p>
            )}
          </div>

          <div class="flex justify-between items-center mt-4 text-xs font-label-caps text-outline-variant">
            <div class="flex items-center gap-2">
              <span class="h-0.5 w-6 bg-primary rounded-full inline-block" />
              <span>Historical Telemetry</span>
            </div>
            <div class="flex items-center gap-2">
              <span class="h-0.5 w-6 bg-tertiary border-t border-dashed border-tertiary rounded-full inline-block" />
              <span>90-Day AI Projection</span>
            </div>
          </div>
        </div>

        {/* Anomaly / Forecast Risk Panel */}
        <div class="glass-panel organic-card rounded-[32px] p-6 md:p-8 border border-primary/10 shadow-2xl flex flex-col justify-between">
          <div>
            <div class="flex items-center justify-between mb-4">
              <div class="flex items-center gap-2">
                <span class="material-symbols-outlined text-terracotta-warm">warning</span>
                <h3 class="font-headline-lg text-lg text-white font-bold editorial-wide">
                  Forecast Anomaly Risk
                </h3>
              </div>
              <span class="px-2.5 py-1 rounded-full text-[10px] font-black uppercase tracking-wider bg-terracotta-warm/20 text-terracotta-warm border border-terracotta-warm/30">
                ACTIVE MODEL
              </span>
            </div>

            <div class="space-y-4 text-sm font-body-sm mb-6">
              <div class="bg-surface-container-high/60 rounded-2xl p-4 border border-primary/10 space-y-2">
                <div class="flex justify-between text-xs font-label-caps text-outline-variant">
                  <span>Current Status:</span>
                  <span class="text-primary font-bold uppercase">{forecast?.current_status || station.status}</span>
                </div>
                <div class="flex justify-between text-xs font-label-caps text-outline-variant">
                  <span>90-Day Projected Status:</span>
                  <span class="text-terracotta-warm font-bold uppercase">{forecast?.projected_status_in_90_days || 'moderate'}</span>
                </div>
                <div class="flex justify-between text-xs font-label-caps text-outline-variant">
                  <span>Model Confidence:</span>
                  <span class="text-secondary font-bold">{(forecast?.confidence ? forecast.confidence * 100 : 92).toFixed(0)}%</span>
                </div>
              </div>

              <p class="text-outline-variant text-xs leading-relaxed italic">
                Hydrological regression models project threshold crossing for parameter{' '}
                <span class="text-primary font-bold">{selectedParam.replace(/_/g, ' ')}</span> on{' '}
                <span class="text-white font-bold">
                  {forecast?.projected_crossing_date
                    ? new Date(forecast.projected_crossing_date).toLocaleDateString()
                    : 'Next 45 Days'}
                </span>
                .
              </p>
            </div>
          </div>

          <button
            onClick={() => onNavigate(`/assistant?q=Analyze forecast anomaly for station ${station.station_id}`)}
            class="w-full bg-sage-muted text-forest-deep py-3.5 px-4 rounded-2xl font-black hover:bg-primary transition-all active:scale-95 text-xs uppercase tracking-widest flex items-center justify-center gap-2 cursor-pointer shadow-lg"
          >
            <span class="material-symbols-outlined text-base">psychology</span>
            Deep AI Analysis
          </button>
        </div>
      </div>
    </div>
  );
};
