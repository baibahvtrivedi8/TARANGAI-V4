import React, { useEffect, useState } from 'react';
import { Station, WaterQualityStatus } from '../types';
import { fetchStations } from '../services/api';
import { GlobeView } from '../components/GlobeView';

interface GlobalViewProps {
  onNavigate: (route: string) => void;
}

export const GlobalView: React.FC<GlobalViewProps> = ({ onNavigate }) => {
  const [stations, setStations] = useState<Station[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedStationId, setSelectedStationId] = useState<string>('');

  useEffect(() => {
    let isMounted = true;
    setLoading(true);

    fetchStations()
      .then(data => {
        if (isMounted) {
          setStations(data);
          if (data.length > 0) setSelectedStationId(data[0].station_id);
          setLoading(false);
        }
      })
      .catch(err => {
        if (isMounted) {
          console.error('Failed to load stations', err);
          setError('Failed to sync live stations network');
          setLoading(false);
        }
      });

    return () => {
      isMounted = false;
    };
  }, []);

  // Compute Global Vitality Index
  const computeVitality = (): number => {
    if (!stations.length) return 84.2;
    const scoreMap: Record<WaterQualityStatus, number> = {
      excellent: 100,
      good: 85,
      moderate: 65,
      poor: 40,
      severe: 15,
    };
    const total = stations.reduce((acc, s) => acc + (scoreMap[s.status] || 70), 0);
    return Number((total / stations.length).toFixed(1));
  };

  // Compute Mean Temperature
  const computeMeanTemp = (): string => {
    if (!stations.length) return '15.4';
    let sum = 0;
    let count = 0;
    stations.forEach(s => {
      const tempReading = s.latest_readings.find(r => r.parameter === 'temperature_c');
      if (tempReading) {
        sum += tempReading.value;
        count++;
      }
    });
    return count > 0 ? (sum / count).toFixed(1) : '15.4';
  };

  // Compute Sensor Health percentage
  const computeSensorHealth = (): string => {
    if (!stations.length) return '99.8';
    const active = stations.filter(s => s.status !== 'severe').length;
    return ((active / stations.length) * 100).toFixed(1);
  };

  const vitality = computeVitality();
  const meanTemp = computeMeanTemp();
  const sensorHealth = computeSensorHealth();

  return (
    <div class="relative h-[calc(100vh-72px)] w-full flex overflow-hidden bg-background">
      {/* Left Sidebar: Station Network */}
      <aside class="hidden md:flex flex-col h-full w-80 bg-surface-dim border-r border-forest-deep/20 py-base gap-2 z-40 transition-all duration-300">
        <div class="px-6 py-4">
          <h2 class="font-headline-lg-mobile text-[22px] font-bold text-sage-muted editorial-wide">
            Network Overview
          </h2>
          <p class="font-body-sm text-body-sm text-outline-variant mt-1">
            {stations.length} Active Telemetry Nodes
          </p>
        </div>

        {loading ? (
          <div class="flex-grow p-6 space-y-3">
            {[1, 2, 3, 4, 5].map(i => (
              <div key={i} class="h-12 bg-surface-container-high/50 rounded-xl animate-pulse" />
            ))}
          </div>
        ) : (
          <div class="flex flex-col gap-1.5 px-4 overflow-y-auto flex-grow">
            {stations.map(station => {
              const isSelected = station.station_id === selectedStationId;
              return (
                <div
                  key={station.station_id}
                  onClick={() => {
                    setSelectedStationId(station.station_id);
                    onNavigate(`/station/${station.station_id}`);
                  }}
                  class={`rounded-xl font-bold flex items-center justify-between px-4 py-3 cursor-pointer group active:scale-[0.98] transition-all duration-150 ${
                    isSelected
                      ? 'bg-secondary-container text-on-secondary-container border border-primary/20'
                      : 'text-on-surface-variant hover:bg-surface-container-high hover:text-on-surface'
                  }`}
                >
                  <div class="flex items-center min-w-0 pr-2">
                    <span class="material-symbols-outlined mr-3 text-lg flex-shrink-0">
                      {station.water_body_type === 'lake'
                        ? 'water'
                        : station.water_body_type === 'estuary'
                        ? 'hub'
                        : station.water_body_type === 'coastal'
                        ? 'waves'
                        : 'eco'}
                    </span>
                    <span class="font-body-sm text-body-sm font-semibold truncate">
                      {station.name}
                    </span>
                  </div>

                  <span
                    class={`h-2.5 w-2.5 rounded-full flex-shrink-0 ${
                      station.status === 'excellent'
                        ? 'bg-primary'
                        : station.status === 'good'
                        ? 'bg-secondary'
                        : station.status === 'moderate'
                        ? 'bg-tertiary'
                        : station.status === 'poor'
                        ? 'bg-terracotta-warm'
                        : 'bg-error'
                    }`}
                  />
                </div>
              );
            })}
          </div>
        )}

        <div class="mt-auto px-4 pb-6 pt-4 border-t border-forest-deep/20">
          <button
            onClick={() => onNavigate('/assistant')}
            class="w-full bg-sage-muted text-forest-deep py-3 px-4 rounded-xl font-extrabold flex items-center justify-center gap-2 hover:bg-primary transition-colors active:scale-95 uppercase text-xs tracking-widest cursor-pointer"
          >
            <span class="material-symbols-outlined">add_circle</span>
            New AI Analysis
          </button>
        </div>
      </aside>

      {/* Main Canvas: 3D Globe Visualization */}
      <section class="flex-grow relative bg-forest-deep overflow-hidden">
        <GlobeView
          stations={stations}
          onSelectStation={id => onNavigate(`/station/${id}`)}
          activeStationId={selectedStationId}
        />

        {/* Dashboard Overlays */}
        <div class="absolute top-6 left-6 z-20 w-80 space-y-4 pointer-events-auto">
          {/* Floating Info Card */}
          <div class="glass-panel rounded-3xl p-6 organic-card shadow-2xl border border-primary/10">
            <div class="flex justify-between items-start mb-4">
              <div class="bg-primary-container/40 px-3 py-1 rounded-full border border-primary/20 flex items-center gap-1.5">
                <span class="h-2 w-2 rounded-full bg-secondary active-glow" />
                <span class="font-label-caps text-[10px] text-primary uppercase tracking-[0.2em] font-black">
                  Live Stream
                </span>
              </div>
              <span class="material-symbols-outlined text-sage-muted text-lg">more_vert</span>
            </div>

            <h3 class="font-headline-lg text-[22px] text-white mb-2 editorial-wide font-extrabold">
              Global Vitality Index
            </h3>

            <div class="flex items-baseline gap-2">
              <span class="font-data-display text-[48px] text-secondary leading-none font-black tracking-tighter">
                {vitality}
              </span>
              <span class="font-body-sm text-body-sm text-outline-variant font-bold">/ 100</span>
            </div>

            <div class="mt-4 h-2 w-full bg-surface-container-highest rounded-full overflow-hidden">
              <div
                class="h-full bg-secondary transition-all duration-700 rounded-full"
                style={{ width: `${Math.min(100, vitality)}%` }}
              />
            </div>

            <p class="font-body-sm text-body-sm text-outline-variant mt-4 font-medium">
              Water vitality index calculated across{' '}
              <span class="text-secondary font-bold">{stations.length} active global nodes</span>.
            </p>
          </div>

          {/* Secondary Data Chip: Mean Surface Temp */}
          <div class="glass-panel rounded-2xl p-4 flex items-center gap-4 border border-primary/10 shadow-lg">
            <div class="h-10 w-10 bg-terracotta-warm/20 rounded-xl flex items-center justify-center text-terracotta-warm">
              <span class="material-symbols-outlined">thermostat</span>
            </div>
            <div>
              <p class="font-label-caps text-[10px] text-outline-variant uppercase tracking-widest font-black">
                Mean Surface Temp
              </p>
              <p class="font-data-display text-lg text-on-surface font-extrabold tracking-tight">
                {meanTemp}°C <span class="text-error text-xs ml-1 font-black">+0.1°</span>
              </p>
            </div>
          </div>
        </div>

        {/* Bottom Data Drawer */}
        <div class="absolute bottom-6 left-1/2 -translate-x-1/2 z-20 w-[92%] max-w-5xl pointer-events-auto">
          <div class="glass-panel rounded-[36px] p-6 md:p-8 organic-card border border-primary/10 flex flex-wrap lg:flex-nowrap gap-6 md:gap-8 items-center shadow-2xl">
            <div class="flex-1 space-y-2">
              <div class="flex items-center gap-2">
                <span class="material-symbols-outlined text-primary text-[20px]">psychology</span>
                <span class="font-label-caps text-[11px] text-primary uppercase font-black tracking-widest">
                  AI Synthesis
                </span>
              </div>
              <p class="font-body-md text-base md:text-lg text-on-surface leading-relaxed italic font-medium">
                "Global hydrological stream parameters indicate stable Dissolved Oxygen ratios across 82% of European and North American river basins. Hypoxia alerts active in Congo & Ganges catchments."
              </p>
            </div>

            <div class="hidden lg:block w-[1px] h-16 bg-forest-deep/40" />

            <div class="flex gap-8 md:gap-10 items-center justify-around w-full lg:w-auto">
              {/* Stat slot 1: Stations Monitored (replaced Species Tracks) */}
              <div class="text-center">
                <p class="font-label-caps text-[10px] text-outline-variant mb-1 uppercase font-black tracking-widest">
                  Stations Monitored
                </p>
                <div class="font-data-display text-[28px] md:text-[32px] text-sage-muted font-black tracking-tighter">
                  {stations.length}
                </div>
              </div>

              {/* Stat slot 2: Sensor Health */}
              <div class="text-center">
                <p class="font-label-caps text-[10px] text-outline-variant mb-1 uppercase font-black tracking-widest">
                  Sensor Health
                </p>
                <div class="font-data-display text-[28px] md:text-[32px] text-secondary font-black tracking-tighter">
                  {sensorHealth}%
                </div>
              </div>

              {/* Stat slot 3: Cloud Latency */}
              <div class="text-center">
                <p class="font-label-caps text-[10px] text-outline-variant mb-1 uppercase font-black tracking-widest">
                  Cloud Latency
                </p>
                <div class="font-data-display text-[28px] md:text-[32px] text-terracotta-warm font-black tracking-tighter">
                  12ms
                </div>
              </div>
            </div>

            <button
              onClick={() => onNavigate(selectedStationId ? `/station/${selectedStationId}` : '/assistant')}
              class="w-full lg:w-auto bg-primary text-forest-deep rounded-full px-8 py-4 font-black hover:bg-leaf-glow transition-all active:scale-95 shadow-lg flex items-center justify-center gap-2 uppercase text-xs tracking-[0.15em] cursor-pointer"
            >
              View Detailed Report
              <span class="material-symbols-outlined">arrow_forward</span>
            </button>
          </div>
        </div>

        {/* Layer Controls */}
        <div class="absolute right-6 top-1/2 -translate-y-1/2 z-20 flex flex-col gap-3 pointer-events-auto">
          <button
            title="Layer Settings"
            class="h-11 w-11 bg-surface-container-highest rounded-full flex items-center justify-center hover:bg-primary/20 text-on-surface transition-all shadow-md cursor-pointer"
          >
            <span class="material-symbols-outlined">layers</span>
          </button>
          <button
            title="Zoom In"
            class="h-11 w-11 bg-surface-container-highest rounded-full flex items-center justify-center hover:bg-primary/20 text-on-surface transition-all shadow-md cursor-pointer"
          >
            <span class="material-symbols-outlined">zoom_in</span>
          </button>
          <button
            title="Zoom Out"
            class="h-11 w-11 bg-surface-container-highest rounded-full flex items-center justify-center hover:bg-primary/20 text-on-surface transition-all shadow-md cursor-pointer"
          >
            <span class="material-symbols-outlined">zoom_out</span>
          </button>
          <div class="h-[1px] w-8 mx-auto bg-outline-variant/30 my-1" />
          <button
            title="Reset 3D Rotation"
            class="h-11 w-11 bg-surface-container-highest rounded-full flex items-center justify-center hover:bg-primary/20 text-on-surface transition-all shadow-md cursor-pointer"
          >
            <span class="material-symbols-outlined">3d_rotation</span>
          </button>
        </div>
      </section>

      {/* Mobile Bottom Navigation */}
      <div class="md:hidden fixed bottom-0 left-0 right-0 h-16 bg-forest-deep/95 backdrop-blur-md flex items-center justify-around z-50 border-t border-forest-deep/30 px-4">
        <button onClick={() => onNavigate('/')} class="text-primary flex flex-col items-center">
          <span class="material-symbols-outlined">dashboard</span>
        </button>
        <button onClick={() => onNavigate('/station/gemstat-amazon-03')} class="text-on-surface-variant flex flex-col items-center">
          <span class="material-symbols-outlined">hub</span>
        </button>
        <button onClick={() => onNavigate('/assistant')} class="text-on-surface-variant flex flex-col items-center">
          <span class="material-symbols-outlined">psychology</span>
        </button>
      </div>
    </div>
  );
};
