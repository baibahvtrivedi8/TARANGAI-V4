import { Station, WaterQualityStatus, Forecast } from '../types';

export const INITIAL_STATIONS: Station[] = [
  {
    station_id: 'gemstat-amazon-03',
    source: 'gemstat',
    name: 'Amazon River Main Channel at Óbidos',
    country: 'Brazil',
    latitude: -1.9083,
    longitude: -55.5186,
    water_body_type: 'river',
    status: 'good',
    last_updated: new Date(Date.now() - 1000 * 60 * 15).toISOString(),
    latest_readings: [
      { parameter: 'dissolved_oxygen_mg_l', value: 7.8, unit: 'mg/L', timestamp: new Date().toISOString() },
      { parameter: 'turbidity_ntu', value: 18.5, unit: 'NTU', timestamp: new Date().toISOString() },
      { parameter: 'ph', value: 6.9, unit: 'pH', timestamp: new Date().toISOString() },
      { parameter: 'nitrate_mg_l', value: 0.85, unit: 'mg/L', timestamp: new Date().toISOString() },
      { parameter: 'biochemical_oxygen_demand_mg_l', value: 1.8, unit: 'mg/L', timestamp: new Date().toISOString() },
      { parameter: 'fecal_coliform_cfu_100ml', value: 85, unit: 'CFU/100mL', timestamp: new Date().toISOString() },
      { parameter: 'temperature_c', value: 27.2, unit: '°C', timestamp: new Date().toISOString() },
    ],
  },
  {
    station_id: 'eea-rhine-002',
    source: 'eea',
    name: 'Rhine River Monitoring Node - Lobith',
    country: 'Netherlands',
    latitude: 51.8425,
    longitude: 6.1133,
    water_body_type: 'river',
    status: 'excellent',
    last_updated: new Date(Date.now() - 1000 * 60 * 8).toISOString(),
    latest_readings: [
      { parameter: 'dissolved_oxygen_mg_l', value: 9.4, unit: 'mg/L', timestamp: new Date().toISOString() },
      { parameter: 'turbidity_ntu', value: 4.2, unit: 'NTU', timestamp: new Date().toISOString() },
      { parameter: 'ph', value: 7.8, unit: 'pH', timestamp: new Date().toISOString() },
      { parameter: 'nitrate_mg_l', value: 1.4, unit: 'mg/L', timestamp: new Date().toISOString() },
      { parameter: 'biochemical_oxygen_demand_mg_l', value: 1.2, unit: 'mg/L', timestamp: new Date().toISOString() },
      { parameter: 'fecal_coliform_cfu_100ml', value: 32, unit: 'CFU/100mL', timestamp: new Date().toISOString() },
      { parameter: 'temperature_c', value: 14.8, unit: '°C', timestamp: new Date().toISOString() },
    ],
  },
  {
    station_id: 'gemstat-ganges-01',
    source: 'gemstat',
    name: 'Ganges River Observatory - Varanasi',
    country: 'India',
    latitude: 25.3176,
    longitude: 82.9739,
    water_body_type: 'river',
    status: 'poor',
    last_updated: new Date(Date.now() - 1000 * 60 * 22).toISOString(),
    latest_readings: [
      { parameter: 'dissolved_oxygen_mg_l', value: 4.8, unit: 'mg/L', timestamp: new Date().toISOString() },
      { parameter: 'turbidity_ntu', value: 42.1, unit: 'NTU', timestamp: new Date().toISOString() },
      { parameter: 'ph', value: 8.2, unit: 'pH', timestamp: new Date().toISOString() },
      { parameter: 'nitrate_mg_l', value: 6.2, unit: 'mg/L', timestamp: new Date().toISOString() },
      { parameter: 'biochemical_oxygen_demand_mg_l', value: 6.8, unit: 'mg/L', timestamp: new Date().toISOString() },
      { parameter: 'fecal_coliform_cfu_100ml', value: 1420, unit: 'CFU/100mL', timestamp: new Date().toISOString() },
      { parameter: 'temperature_c', value: 28.5, unit: '°C', timestamp: new Date().toISOString() },
    ],
  },
  {
    station_id: 'usgs-05587455',
    source: 'usgs',
    name: 'Mississippi River at Grafton, IL',
    country: 'United States',
    latitude: 38.9687,
    longitude: -90.4323,
    water_body_type: 'river',
    status: 'moderate',
    last_updated: new Date(Date.now() - 1000 * 60 * 30).toISOString(),
    latest_readings: [
      { parameter: 'dissolved_oxygen_mg_l', value: 6.5, unit: 'mg/L', timestamp: new Date().toISOString() },
      { parameter: 'turbidity_ntu', value: 24.8, unit: 'NTU', timestamp: new Date().toISOString() },
      { parameter: 'ph', value: 7.6, unit: 'pH', timestamp: new Date().toISOString() },
      { parameter: 'nitrate_mg_l', value: 4.1, unit: 'mg/L', timestamp: new Date().toISOString() },
      { parameter: 'biochemical_oxygen_demand_mg_l', value: 3.4, unit: 'mg/L', timestamp: new Date().toISOString() },
      { parameter: 'fecal_coliform_cfu_100ml', value: 210, unit: 'CFU/100mL', timestamp: new Date().toISOString() },
      { parameter: 'temperature_c', value: 19.2, unit: '°C', timestamp: new Date().toISOString() },
    ],
  },
  {
    station_id: 'epa-chesapeake-01',
    source: 'epa_wqx',
    name: 'Chesapeake Bay Mainstem Station CB4.3C',
    country: 'United States',
    latitude: 38.552,
    longitude: -76.418,
    water_body_type: 'estuary',
    status: 'moderate',
    last_updated: new Date(Date.now() - 1000 * 60 * 12).toISOString(),
    latest_readings: [
      { parameter: 'dissolved_oxygen_mg_l', value: 5.9, unit: 'mg/L', timestamp: new Date().toISOString() },
      { parameter: 'turbidity_ntu', value: 16.2, unit: 'NTU', timestamp: new Date().toISOString() },
      { parameter: 'ph', value: 7.9, unit: 'pH', timestamp: new Date().toISOString() },
      { parameter: 'nitrate_mg_l', value: 2.8, unit: 'mg/L', timestamp: new Date().toISOString() },
      { parameter: 'biochemical_oxygen_demand_mg_l', value: 2.9, unit: 'mg/L', timestamp: new Date().toISOString() },
      { parameter: 'fecal_coliform_cfu_100ml', value: 110, unit: 'CFU/100mL', timestamp: new Date().toISOString() },
      { parameter: 'temperature_c', value: 21.4, unit: '°C', timestamp: new Date().toISOString() },
    ],
  },
  {
    station_id: 'gemstat-congo-02',
    source: 'gemstat',
    name: 'Congo Basin Hydro Station - Brazzaville',
    country: 'Congo',
    latitude: -4.2634,
    longitude: 15.2429,
    water_body_type: 'river',
    status: 'severe',
    last_updated: new Date(Date.now() - 1000 * 60 * 5).toISOString(),
    latest_readings: [
      { parameter: 'dissolved_oxygen_mg_l', value: 3.2, unit: 'mg/L', timestamp: new Date().toISOString() },
      { parameter: 'turbidity_ntu', value: 68.4, unit: 'NTU', timestamp: new Date().toISOString() },
      { parameter: 'ph', value: 5.8, unit: 'pH', timestamp: new Date().toISOString() },
      { parameter: 'nitrate_mg_l', value: 8.9, unit: 'mg/L', timestamp: new Date().toISOString() },
      { parameter: 'biochemical_oxygen_demand_mg_l', value: 9.2, unit: 'mg/L', timestamp: new Date().toISOString() },
      { parameter: 'fecal_coliform_cfu_100ml', value: 3400, unit: 'CFU/100mL', timestamp: new Date().toISOString() },
      { parameter: 'temperature_c', value: 29.8, unit: '°C', timestamp: new Date().toISOString() },
    ],
  },
  {
    station_id: 'usgs-pacific-01',
    source: 'usgs',
    name: 'Pacific Marine Coastal Buoy - Puget Sound',
    country: 'United States',
    latitude: 47.6062,
    longitude: -122.3321,
    water_body_type: 'coastal',
    status: 'excellent',
    last_updated: new Date(Date.now() - 1000 * 60 * 18).toISOString(),
    latest_readings: [
      { parameter: 'dissolved_oxygen_mg_l', value: 9.8, unit: 'mg/L', timestamp: new Date().toISOString() },
      { parameter: 'turbidity_ntu', value: 2.1, unit: 'NTU', timestamp: new Date().toISOString() },
      { parameter: 'ph', value: 8.1, unit: 'pH', timestamp: new Date().toISOString() },
      { parameter: 'nitrate_mg_l', value: 0.6, unit: 'mg/L', timestamp: new Date().toISOString() },
      { parameter: 'biochemical_oxygen_demand_mg_l', value: 0.9, unit: 'mg/L', timestamp: new Date().toISOString() },
      { parameter: 'fecal_coliform_cfu_100ml', value: 12, unit: 'CFU/100mL', timestamp: new Date().toISOString() },
      { parameter: 'temperature_c', value: 11.2, unit: '°C', timestamp: new Date().toISOString() },
    ],
  },
  {
    station_id: 'gemstat-victoria-01',
    source: 'gemstat',
    name: 'Lake Victoria Coastal Gulf - Kisumu',
    country: 'Kenya',
    latitude: -0.1022,
    longitude: 34.7617,
    water_body_type: 'lake',
    status: 'poor',
    last_updated: new Date(Date.now() - 1000 * 60 * 40).toISOString(),
    latest_readings: [
      { parameter: 'dissolved_oxygen_mg_l', value: 4.1, unit: 'mg/L', timestamp: new Date().toISOString() },
      { parameter: 'turbidity_ntu', value: 38.5, unit: 'NTU', timestamp: new Date().toISOString() },
      { parameter: 'ph', value: 8.4, unit: 'pH', timestamp: new Date().toISOString() },
      { parameter: 'nitrate_mg_l', value: 5.7, unit: 'mg/L', timestamp: new Date().toISOString() },
      { parameter: 'biochemical_oxygen_demand_mg_l', value: 7.1, unit: 'mg/L', timestamp: new Date().toISOString() },
      { parameter: 'fecal_coliform_cfu_100ml', value: 1850, unit: 'CFU/100mL', timestamp: new Date().toISOString() },
      { parameter: 'temperature_c', value: 26.4, unit: '°C', timestamp: new Date().toISOString() },
    ],
  },
  {
    station_id: 'eea-danube-104',
    source: 'eea',
    name: 'Danube River Delta Monitoring Station',
    country: 'Romania',
    latitude: 45.1667,
    longitude: 29.65,
    water_body_type: 'estuary',
    status: 'good',
    last_updated: new Date(Date.now() - 1000 * 60 * 11).toISOString(),
    latest_readings: [
      { parameter: 'dissolved_oxygen_mg_l', value: 8.1, unit: 'mg/L', timestamp: new Date().toISOString() },
      { parameter: 'turbidity_ntu', value: 11.4, unit: 'NTU', timestamp: new Date().toISOString() },
      { parameter: 'ph', value: 7.7, unit: 'pH', timestamp: new Date().toISOString() },
      { parameter: 'nitrate_mg_l', value: 2.1, unit: 'mg/L', timestamp: new Date().toISOString() },
      { parameter: 'biochemical_oxygen_demand_mg_l', value: 2.2, unit: 'mg/L', timestamp: new Date().toISOString() },
      { parameter: 'fecal_coliform_cfu_100ml', value: 95, unit: 'CFU/100mL', timestamp: new Date().toISOString() },
      { parameter: 'temperature_c', value: 16.9, unit: '°C', timestamp: new Date().toISOString() },
    ],
  },
  {
    station_id: 'usgs-11455420',
    source: 'usgs',
    name: 'Sacramento River at Freeport, CA',
    country: 'United States',
    latitude: 38.4563,
    longitude: -121.5008,
    water_body_type: 'river',
    status: 'excellent',
    last_updated: new Date(Date.now() - 1000 * 60 * 14).toISOString(),
    latest_readings: [
      { parameter: 'dissolved_oxygen_mg_l', value: 9.1, unit: 'mg/L', timestamp: new Date().toISOString() },
      { parameter: 'turbidity_ntu', value: 5.8, unit: 'NTU', timestamp: new Date().toISOString() },
      { parameter: 'ph', value: 7.5, unit: 'pH', timestamp: new Date().toISOString() },
      { parameter: 'nitrate_mg_l', value: 1.1, unit: 'mg/L', timestamp: new Date().toISOString() },
      { parameter: 'biochemical_oxygen_demand_mg_l', value: 1.4, unit: 'mg/L', timestamp: new Date().toISOString() },
      { parameter: 'fecal_coliform_cfu_100ml', value: 40, unit: 'CFU/100mL', timestamp: new Date().toISOString() },
      { parameter: 'temperature_c', value: 15.1, unit: '°C', timestamp: new Date().toISOString() },
    ],
  },
  {
    station_id: 'epa-greatlakes-09',
    source: 'epa_wqx',
    name: 'Lake Erie Central Basin Buoy',
    country: 'United States',
    latitude: 41.8,
    longitude: -81.7,
    water_body_type: 'lake',
    status: 'moderate',
    last_updated: new Date(Date.now() - 1000 * 60 * 25).toISOString(),
    latest_readings: [
      { parameter: 'dissolved_oxygen_mg_l', value: 6.2, unit: 'mg/L', timestamp: new Date().toISOString() },
      { parameter: 'turbidity_ntu', value: 14.5, unit: 'NTU', timestamp: new Date().toISOString() },
      { parameter: 'ph', value: 8.0, unit: 'pH', timestamp: new Date().toISOString() },
      { parameter: 'nitrate_mg_l', value: 3.2, unit: 'mg/L', timestamp: new Date().toISOString() },
      { parameter: 'biochemical_oxygen_demand_mg_l', value: 3.1, unit: 'mg/L', timestamp: new Date().toISOString() },
      { parameter: 'fecal_coliform_cfu_100ml', value: 160, unit: 'CFU/100mL', timestamp: new Date().toISOString() },
      { parameter: 'temperature_c', value: 18.7, unit: '°C', timestamp: new Date().toISOString() },
    ],
  },
  {
    station_id: 'gemstat-mekong-05',
    source: 'gemstat',
    name: 'Mekong Delta Observatory - Cần Thơ',
    country: 'Vietnam',
    latitude: 10.0452,
    longitude: 105.7469,
    water_body_type: 'estuary',
    status: 'good',
    last_updated: new Date(Date.now() - 1000 * 60 * 19).toISOString(),
    latest_readings: [
      { parameter: 'dissolved_oxygen_mg_l', value: 7.2, unit: 'mg/L', timestamp: new Date().toISOString() },
      { parameter: 'turbidity_ntu', value: 21.0, unit: 'NTU', timestamp: new Date().toISOString() },
      { parameter: 'ph', value: 7.2, unit: 'pH', timestamp: new Date().toISOString() },
      { parameter: 'nitrate_mg_l', value: 1.9, unit: 'mg/L', timestamp: new Date().toISOString() },
      { parameter: 'biochemical_oxygen_demand_mg_l', value: 2.5, unit: 'mg/L', timestamp: new Date().toISOString() },
      { parameter: 'fecal_coliform_cfu_100ml', value: 240, unit: 'CFU/100mL', timestamp: new Date().toISOString() },
      { parameter: 'temperature_c', value: 28.1, unit: '°C', timestamp: new Date().toISOString() },
    ],
  }
];

export function generateForecast(stationId: string, param: string): Forecast {
  const station = INITIAL_STATIONS.find(s => s.station_id === stationId) || INITIAL_STATIONS[0];
  const reading = station.latest_readings.find(r => r.parameter === param) || station.latest_readings[0];
  const baseValue = reading ? reading.value : 7.5;

  const now = Date.now();
  const dayMs = 24 * 60 * 60 * 1000;
  
  // Historical 12 weekly data points
  const history = Array.from({ length: 12 }).map((_, i) => {
    const time = new Date(now - (12 - i) * 7 * dayMs).toISOString();
    // generate realistic trend
    const noise = (Math.sin(i / 2) * 0.4) + ((i % 3) - 1) * 0.15;
    const value = Math.max(0.1, Number((baseValue - 0.05 * (12 - i) + noise).toFixed(2)));
    return { timestamp: time, value };
  });

  // Current value
  history.push({ timestamp: new Date().toISOString(), value: Number(baseValue.toFixed(2)) });

  // Projected crossing date
  const isDeclining = param === 'dissolved_oxygen_mg_l' || param === 'ph';
  const crossingDays = station.status === 'severe' ? 5 : station.status === 'poor' ? 22 : station.status === 'moderate' ? 48 : 82;
  const crossingDate = new Date(now + crossingDays * dayMs).toISOString();

  let projectedStatus: WaterQualityStatus = station.status;
  if (station.status === 'good') projectedStatus = 'moderate';
  else if (station.status === 'moderate') projectedStatus = 'poor';
  else if (station.status === 'poor') projectedStatus = 'severe';

  return {
    station_id: station.station_id,
    parameter: param,
    history,
    projected_crossing_date: crossingDate,
    current_status: station.status,
    projected_status_in_90_days: projectedStatus,
    confidence: 0.92,
    method: 'Holt-Winters Exponential Smoothing & Hydrological AI Inflow Model',
  };
}
