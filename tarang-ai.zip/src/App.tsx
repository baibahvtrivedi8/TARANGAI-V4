import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { GlobalView } from './pages/GlobalView';
import { StationDetail } from './pages/StationDetail';
import { AiAssistant } from './pages/AiAssistant';

export default function App() {
  const [currentPath, setCurrentPath] = useState<string>(() => window.location.pathname || '/');
  const [initialSearchQuery, setInitialSearchQuery] = useState<string>('');

  useEffect(() => {
    const handlePopState = () => {
      setCurrentPath(window.location.pathname || '/');
    };
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  const navigate = (route: string) => {
    let cleanRoute = route;
    let query = '';

    if (route.includes('?q=')) {
      const parts = route.split('?q=');
      cleanRoute = parts[0];
      query = decodeURIComponent(parts[1] || '');
      setInitialSearchQuery(query);
    } else {
      setInitialSearchQuery('');
    }

    window.history.pushState({}, '', route);
    setCurrentPath(cleanRoute);
  };

  // Route matching
  const renderScreen = () => {
    if (currentPath.startsWith('/station/')) {
      const stationId = currentPath.replace('/station/', '');
      return <StationDetail stationId={stationId} onNavigate={navigate} />;
    }

    if (currentPath === '/assistant') {
      return <AiAssistant initialQuery={initialSearchQuery} onNavigate={navigate} />;
    }

    // Default to Global View
    return <GlobalView onNavigate={navigate} />;
  };

  return (
    <div class="min-h-screen w-full bg-background text-on-surface font-body-md flex flex-col selection:bg-primary selection:text-on-primary overflow-hidden">
      <Header currentRoute={currentPath} onNavigate={navigate} />
      <main class="flex-grow w-full relative">{renderScreen()}</main>
    </div>
  );
}
