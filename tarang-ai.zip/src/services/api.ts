import { Station, Forecast, SearchResponse } from '../types';

const API_BASE_URL = (import.meta.env.VITE_API_BASE_URL || '').trim();

const getUrl = (path: string) => {
  if (API_BASE_URL && API_BASE_URL !== 'http://localhost:8000') {
    const base = API_BASE_URL.replace(/\/$/, '');
    return `${base}${path}`;
  }
  return `/api${path}`;
};

export async function fetchStations(): Promise<Station[]> {
  try {
    const url = getUrl('/stations');
    const res = await fetch(url);
    if (!res.ok) throw new Error(`HTTP error ${res.status}`);
    return await res.json();
  } catch (err) {
    console.warn('Primary fetch failed, attempting fallback /api/stations:', err);
    const res = await fetch('/api/stations');
    if (!res.ok) throw new Error('Failed to fetch stations');
    return await res.json();
  }
}

export async function fetchStationById(id: string): Promise<Station> {
  try {
    const url = getUrl(`/stations/${id}`);
    const res = await fetch(url);
    if (!res.ok) throw new Error(`HTTP error ${res.status}`);
    return await res.json();
  } catch (err) {
    const res = await fetch(`/api/stations/${id}`);
    if (!res.ok) throw new Error(`Station ${id} not found`);
    return await res.json();
  }
}

export async function fetchStationForecast(
  id: string,
  parameter = 'dissolved_oxygen_mg_l',
  horizon = 90
): Promise<Forecast> {
  try {
    const url = getUrl(`/stations/${id}/forecast?parameter=${encodeURIComponent(parameter)}&horizon_days=${horizon}`);
    const res = await fetch(url);
    if (!res.ok) throw new Error(`HTTP error ${res.status}`);
    return await res.json();
  } catch (err) {
    const res = await fetch(`/api/stations/${id}/forecast?parameter=${encodeURIComponent(parameter)}&horizon_days=${horizon}`);
    if (!res.ok) throw new Error(`Forecast failed for station ${id}`);
    return await res.json();
  }
}

export async function searchStations(query: string): Promise<SearchResponse> {
  try {
    const url = getUrl('/search');
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ query }),
    });
    if (!res.ok) throw new Error(`HTTP error ${res.status}`);
    return await res.json();
  } catch (err) {
    const res = await fetch('/api/search', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ query }),
    });
    if (!res.ok) throw new Error('Search failed');
    return await res.json();
  }
}
